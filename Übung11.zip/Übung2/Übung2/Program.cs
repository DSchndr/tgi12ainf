﻿using System;
using System.Threading;

namespace Übung2
{
    class Program
    {
        static void Main(string[] args)
        {
            Stern s = new Stern();
            //s.zeichnenStern();
            Console.ReadLine();
            zeichnenSternenhimmel3(5);
            Console.ReadLine();
        }

        public static void zeichnenSternenhimmel2(int anzahlSterne) {
            Random r = new Random();
            Stern s = new Stern();
            for (int i = 0; i < anzahlSterne; i++) {
                s.setLaenge(r.Next(0, 20));
                s.setStartpunkt(r.Next(0, 50), r.Next(0, 50));
                s.zeichnenStern();
            }
        }
        public static void zeichnenSternenhimmel3(int anzahlSterne) {
            Stern[] sternArray = new Stern[anzahlSterne];
            Random r = new Random();
            for (int i = 0; i < anzahlSterne; i++) {
                sternArray[i] = new Stern();
                sternArray[i].setLaenge(r.Next(0, 20));
                sternArray[i].setStartpunkt(r.Next(0, 50), r.Next(0, 50));
                sternArray[i].zeichnenStern();
                Thread.Sleep(100);
            }
            for (int i = 0; i < anzahlSterne; i++) {
                Thread.Sleep(100);
                sternArray[i].zeichnenStern(' ');
            }
        }

    }

    class Stern
    {
        private int derStartpunktx;
        private int derStartpunkty;
        private int dieLaenge;

        public Stern() {
            derStartpunktx = 0;
            derStartpunkty = 0;
            dieLaenge = 15;
        }

        public void zeichnenStern(char zeichen = '*') {
            for (int y = 0; y < dieLaenge; y++) {
                Console.SetCursorPosition(derStartpunktx + y, derStartpunkty + y);
                Console.Write(zeichen);

                //Ungerade? -> um 1 nach links
                Console.SetCursorPosition(derStartpunktx + dieLaenge - (dieLaenge % 2) - y, derStartpunkty + y);
                Console.Write(zeichen);

                Console.SetCursorPosition(derStartpunktx + dieLaenge / 2, derStartpunkty + y);
                Console.Write(zeichen);
                Console.SetCursorPosition(derStartpunktx + y, derStartpunkty + dieLaenge / 2);
                Console.Write(zeichen);
            }
        }

        public void setStartpunkt(int x, int y) {
            derStartpunktx = x;
            derStartpunkty = y;
        }

        public void setLaenge(int dieLaengeM) {
            dieLaenge = dieLaengeM;
        }


    }
}
