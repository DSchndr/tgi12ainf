﻿using System;

namespace Übung5
{
    class Program
    {
        static void Main(string[] args)
        {
            Koerperteil[] kt1 = new Koerperteil[4];
            kt1[0] = new Koerperteil("linker Arm");
            kt1[1] = new Koerperteil("rechter Arm");
            kt1[2] = new Koerperteil("linkes Bein");
            kt1[3] = new Koerperteil("rechtes Bein");

            InneresOrgan[] io1 = new InneresOrgan[2];
            io1[0] = new InneresOrgan("Herz");
            io1[1] = new InneresOrgan("Lunge");

            Person p1 = new Person("Heinz", io1, kt1);


            Console.WriteLine(p1.getName());
            foreach(Koerperteil kt in p1.getKoerperteile()) {
                Console.WriteLine(kt.getKoerperteil());
            }
            foreach (InneresOrgan io in p1.getInnereOrgane()) {
                Console.WriteLine(io.getInneresOrgan());
            }

            Console.ReadLine();
        }
    }

    class Person
    {
        private string derName;
        private InneresOrgan[] dieInnerenOrgane;
        private Koerperteil[] dieKoerperteile;

        public Person(string pName, InneresOrgan[] pInneresOrgan, Koerperteil[] pKoerperteile) {
            derName = pName;
            dieInnerenOrgane = pInneresOrgan;
            dieKoerperteile = pKoerperteile;
        }
        //public void setName(string pName) { derName = pName; }
        public string getName() { return derName; }
        public Koerperteil[] getKoerperteile() { return dieKoerperteile; }
        public InneresOrgan[] getInnereOrgane() { return dieInnerenOrgane; }
    }

    class Koerperteil
    {
        private string dasKoerperteil;
        public Koerperteil(string pKoerperteil) {
            dasKoerperteil = pKoerperteil;
        }
        public string getKoerperteil() { return dasKoerperteil; }
    }

    class InneresOrgan
    {
        private string dasOrgan;

        public InneresOrgan(string pOrgan) {
            dasOrgan = pOrgan;
        }
        public string getInneresOrgan() { return dasOrgan; }
    }
}
