﻿using System;

namespace übung6
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;
            Abteilung a1 = new Abteilung("Einkauf");
            Mitarbeiter m1 = new Mitarbeiter("Maier", 1000);
            a1.verbindeZuMitarbeiter(m1);
            a1.druckeGehaltsliste();
            Console.ReadKey();
        }
    }


    class Abteilung
    {
        private string dieBezeichnung;
        private Mitarbeiter derArbeiter;

        public void druckeGehaltsliste() {
            Console.WriteLine($"Gehaltsliste der Abteilung {dieBezeichnung}");
            Console.WriteLine($"Der Angestellte {derArbeiter.getName()} bekommt {derArbeiter.getGehalt()}€ Gehalt");
        }

        public string getBezeichnung() {
            return dieBezeichnung;
        }

        public Abteilung(string pBezeichnung) {
            dieBezeichnung = pBezeichnung;
        }

        public void verbindeZuMitarbeiter(Mitarbeiter pMitarbeiter) {
            derArbeiter = pMitarbeiter;
        }
    }

    class Mitarbeiter
    {
        private string derName;
        private double dasGehalt;

        public string getName() { return derName; }
        public double getGehalt() { return dasGehalt; }
        public Mitarbeiter(string pName, double pGehalt) {
            derName = pName;
            dasGehalt = pGehalt;
        }
    }
}
