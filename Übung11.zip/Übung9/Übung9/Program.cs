﻿using System;

namespace Übung9
{
    class Program
    {
        public class Mitarbeiter
        {
            private string derName;
            protected float dieAnzahlStunden;

            public Mitarbeiter(string name) {
                derName = name;
            }
            public string getName() {
                return derName;
            }
            public void setStunden(float stunden) {
                dieAnzahlStunden = stunden;
            }
            public float getStunden() {
                return dieAnzahlStunden;
            }
            public virtual void berechneGehalt() {
                Console.WriteLine($"Gehalt: {dieAnzahlStunden * 100}");
            }
        }
        public class Chef : Mitarbeiter
        {
            public Chef(string name) : base(name) { }
            public override void berechneGehalt() {
                Console.WriteLine($"Gehalt: {dieAnzahlStunden * 100}");
            }
        }
        static void Main(string[] args) {
            Mitarbeiter[] derMitarbeiter = new Mitarbeiter[2];
            derMitarbeiter[0] = new Mitarbeiter("Maier");
            derMitarbeiter[0].setStunden(10f);
            derMitarbeiter[1] = new Chef("Schmid");
            derMitarbeiter[1].setStunden(10f);
            derMitarbeiter[0].berechneGehalt();
            derMitarbeiter[1].berechneGehalt();
            Console.ReadLine();
        }
    }
}