﻿using System;

namespace übung7
{
    class Program
    {
        static void Main(string[] args) {
            Console.OutputEncoding = System.Text.Encoding.UTF8;
            Abteilung a1 = new Abteilung("Einkauf");
            Mitarbeiter[] m1 = new Mitarbeiter[2];
            m1[0] = new Mitarbeiter("Maier", 1000);
            m1[1] = new Mitarbeiter("Schmid", 1500);
            a1.verbindeZuMitarbeiter(m1[0]);
            a1.verbindeZuMitarbeiter(m1[1]);
            a1.druckeGehaltsliste();
            Console.ReadKey();
        }
    }


    class Abteilung
    {
        private string dieBezeichnung;
        private Mitarbeiter[] dieMitarbeiter = new Mitarbeiter[100];
        private int numMitarbeiter = 0;
        public void druckeGehaltsliste() {
            Console.WriteLine($"Gehaltsliste der Abteilung {dieBezeichnung}");
            for(int i = 0; i<numMitarbeiter; i++) {
                var derArbeiter = dieMitarbeiter[i];
                Console.WriteLine($"Der Angestellte {derArbeiter.getName()} bekommt {derArbeiter.getGehalt()}€ Gehalt");
            }
        }

        public string getBezeichnung() {
            return dieBezeichnung;
        }

        public Abteilung(string pBezeichnung) {
            dieBezeichnung = pBezeichnung;
        }

        public void verbindeZuMitarbeiter(Mitarbeiter pMitarbeiter) {
            dieMitarbeiter[numMitarbeiter++] = pMitarbeiter;
        }
    }

    class Mitarbeiter
    {
        private string derName;
        private double dasGehalt;

        public string getName() { return derName; }
        public double getGehalt() { return dasGehalt; }
        public Mitarbeiter(string pName, double pGehalt) {
            derName = pName;
            dasGehalt = pGehalt;
        }
    }
}
