﻿using System;
using System.Threading;

namespace Uebung1
{
    class Program
    {
        static void Main(string[] args) {
            //Stern4(0,0, 15);
            //Console.ReadLine();
            Stern5(1,1, 16);
            Console.ReadLine();
            Stern1();
            Console.ReadLine();
            Console.Clear();
            Console.Write("Amnt: ");
            int amnt = Convert.ToInt16(Console.ReadLine());
            Console.Clear();
            Stern2(amnt);
            Console.ReadLine();
            Console.Clear();
            Console.Write("PosX: ");
            int x = Convert.ToInt16(Console.ReadLine());
            Console.Write("PosY: ");
            int y = Convert.ToInt16(Console.ReadLine());
            Console.Write("Amnt: ");
            amnt = Convert.ToInt16(Console.ReadLine());
            Stern3(x,y,amnt);
            Console.ReadLine();
            Console.Clear();
            Console.Write("Amnt: ");
            amnt = Convert.ToInt16(Console.ReadLine());
            Console.Clear();
            Sternenhimmel1(amnt);
            Console.ReadLine();
        }


        static void Stern1() {
            int y = 0;
            for (y = 0; y < 15; y++) {
                Console.SetCursorPosition(y, y);
                Console.Write('*');
                Console.SetCursorPosition(14-y, y);
                Console.Write('*');
                Console.SetCursorPosition(7, y);
                Console.Write('*');
                Console.SetCursorPosition(y, 7);
                Console.Write('*');
            }
        }
        static void Stern2(int anzahl) {
            int y = 0;
            for (y = 0; y < anzahl; y++) {
                Console.SetCursorPosition(y, y);
                Console.Write('*');
                //Ungerade? -> um 1 nach links
                Console.SetCursorPosition(anzahl - (anzahl % 2) - y, y);
                Console.Write('*');
                Console.SetCursorPosition(anzahl/2, y);
                Console.Write('*');
                Console.SetCursorPosition(y, anzahl/2);
                Console.Write('*');
            }
        }

        static void Stern3(int Startpunktx, int Startpunkty, int anzahl) {
            int y = 0;
            for (y = 0; y < anzahl; y++) {
                Console.SetCursorPosition(Startpunktx + y, Startpunkty + y);
                Console.Write('*');

                //Ungerade? -> um 1 nach links
                Console.SetCursorPosition(Startpunktx + anzahl - (anzahl % 2) - y, Startpunkty + y);
                Console.Write('*');

                Console.SetCursorPosition(Startpunktx + anzahl / 2, Startpunkty + y);
                Console.Write('*');
                Console.SetCursorPosition(Startpunktx + y, Startpunkty + anzahl / 2);
                Console.Write('*');
            }
        }

        static void Sternenhimmel1(int anzahlSterne) {
            Random r = new Random();
            for (int i = 0; i < anzahlSterne; i++) {
                Stern3(r.Next(0, 50), r.Next(0, 50), r.Next(0, 20));
            }
        }

        //TODO
        static void Stern4(int Startpunktx, int Startpunkty, int anzahl) {
            int rot = 2;
            
            int y = 0;
            for (y = 0; y < anzahl; y++) {
                Console.SetCursorPosition(Startpunktx + y, Startpunkty + y);
                Console.Write('*');

                //Ungerade? -> um 1 nach links
                Console.SetCursorPosition(Startpunktx + anzahl - (anzahl % 2) - y, Startpunkty + y);
                Console.Write('*');

                Console.SetCursorPosition(Startpunktx + anzahl / 2, Startpunkty + y);
                Console.Write('*');
                Console.SetCursorPosition(Startpunktx + y, Startpunkty + anzahl / 2);
                Console.Write('*');
            }
        }



        static void Stern5(int Startpunktx, int Startpunkty, int anzahl) {
            Console.SetCursorPosition(Startpunktx, Startpunkty);
            for (int x = 0; x<anzahl; x++) {
                for (int y = 0; y<anzahl; y++) {
                    Console.Write( 
                        ( 
                            ( (x == y) || (x == anzahl / 2) || (y == anzahl / 2) || (anzahl - x - (anzahl % 2) == y) ) 
                            && ( (y <= anzahl/2 && x <= anzahl / 2) ) 
                        ) 
                        ? '*' : ' ');
                }
                Console.SetCursorPosition(Startpunktx, Startpunkty++);
            }
        }

    }
}
