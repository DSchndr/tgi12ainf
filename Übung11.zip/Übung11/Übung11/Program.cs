﻿using System;

namespace Übung11
{
    class Program
    {
        static void Main(string[] args) {
            Spiel s = new Spiel();
            Console.WriteLine("SchnickSchnackSchnuck");
            Console.Write("Name von Spieler 1: ");
            s.addSpieler(new Spiel.Spieler(Console.ReadLine()));
            Console.Write("Name von Spieler 2: ");
            s.addSpieler(new Spiel.Spieler(Console.ReadLine()));


        }
    }
    public class Spiel
    {
        /* 0: Schere
         * 1: Stein
         * 2: Papier
         */

        public int dieAnzahlSpieler = 0;
        private Spieler[] derSpieler = new Spieler[10];

        private void anzeigenSpielstand() { }
        private void ermittleSieger(int S1Symbol, int S2Symbol) {
            int sieger = 0;
            if (S1Symbol == 0 && S2Symbol == 0) { sieger = 0; goto lExit; }
            if (S1Symbol == 1 && S2Symbol == 1) { sieger = 0; goto lExit; }
            if (S1Symbol == 2 && S2Symbol == 2) { sieger = 0; goto lExit; }

            if (S1Symbol == 0 && S2Symbol == 0) { sieger = 0; goto lExit; }
            if (S1Symbol == 1 && S2Symbol == 0) { sieger = 0; goto lExit; }
            if (S1Symbol == 2 && S2Symbol == 0) { sieger = 0; goto lExit; }

            if (S1Symbol == 0 && S2Symbol == 0) { sieger = 0; goto lExit; }
            if (S1Symbol == 0 && S2Symbol == 1) { sieger = 0; goto lExit; }
            if (S1Symbol == 0 && S2Symbol == 2) { sieger = 0; goto lExit; }


            lExit:

        }
        public void durchführenSpielzug() {

        }

        public void addSpieler(Spieler pSpieler) {
            derSpieler[dieAnzahlSpieler++] = pSpieler;
        }

        public Spiel() {

        }

        public class Spieler
        {
            public int diePunkte = 0;
            public string derName;

            public int getPunkte() { return diePunkte; }
            public string getName() { return derName; }
            public void addPunkte() { }
            public void addPunkte(int pPunkte) { }
            public int bestimmeSymbol() { return 0; }
            public Spieler(string pName) { derName = pName; }

        }

    }

}
