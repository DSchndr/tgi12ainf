﻿using System;

namespace Uebung3
{
    class Program
    {
        static void Main(string[] args)
        {
            double x, y;
            Console.WriteLine("");
            Console.Write("X: ");
            x=Convert.ToDouble(Console.ReadLine());
            Console.Write("\nY: ");
            y = Convert.ToDouble(Console.ReadLine());
            Rechteck r = new Rechteck(x,y);
            Quadrat q = new Quadrat(x);
            Kreis k = new Kreis(x);
            r.berechneFlaeche();
            r.gibFlaecheAus();
            q.berechneFlaeche();
            q.gibFlaecheAus();
            k.berechneFlaeche();
            k.gibFlaecheAus();
            Console.ReadLine();
        }
    }
    abstract class GeomFigur {
        protected double xWert;
        protected double flaeche;

        public abstract void berechneFlaeche();
        public void gibFlaecheAus() {
            Console.WriteLine($"Flaeche: {flaeche} ");
        }

    }

    class Quadrat : GeomFigur
    {
        public Quadrat(double x) {
            xWert = x;
        }
        public override void berechneFlaeche() {
            flaeche = xWert * xWert;
        }
    }

    class Rechteck : GeomFigur
    {
        private double yWert;
        public Rechteck(double x, double y) {
            xWert = x;
            yWert = y;
        }
        public override void berechneFlaeche() {
            flaeche = xWert * yWert;
        }
    }

    class Kreis : GeomFigur
    {
        private double PI;

        public Kreis(double x) {
            PI = System.Math.PI;
            xWert = x;
        }

        public override void berechneFlaeche() {
            flaeche = PI * xWert * xWert;
        }
    }

}
