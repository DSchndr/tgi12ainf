﻿using System;

namespace Übung4
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;
            Mitglied.setMitgliedsbeitrag(100.0);
            Console.WriteLine($"Mitgliedsbeitrag: {Mitglied.getMitgliedsbeitrag()}€");

            Mitglied[] mitgliedarr = new Mitglied[10];

            mitgliedarr[0] = new Mitglied("Hans", "Meier", 30);
            mitgliedarr[1] = new Mitglied("Georg", "Schmitt", 20);

            /*
            for (int i = 0; i < mitgliedarr.Length; i++) {
                Console.Write("");
            }
            */

            for (int i = 0; i <= 1; i++) {
                Console.WriteLine($"{mitgliedarr[i].getVorname()} {mitgliedarr[i].getNachname()} {mitgliedarr[i].getAlter()} Jahre alt, Mitgliedsnummer:{mitgliedarr[i].getMitgliedsnummer()}");
            }
            Console.ReadLine();
        }
    }

    class Mitglied
    {
        private string derVorname;
        private string derNachname;
        private int dasAlter;
        private int dieMitgliedsnummer;
        private static double derMitgliedsbeitrag = 0;
        private static int dieAnzahl;

        public Mitglied(string pVorname, string pNachname, int pAlter) {
            derVorname = pVorname;
            derNachname = pNachname;
            dasAlter = pAlter;
            dieAnzahl++;
            dieMitgliedsnummer = dieAnzahl;
        }

        public string getVorname() { return derVorname; }
        public string getNachname() { return derNachname; }
        public int getAlter() { return dasAlter; }
        public int getMitgliedsnummer() { return dieMitgliedsnummer; }
        public int getAnzahl() { return dieAnzahl; }
        public static double getMitgliedsbeitrag() { return derMitgliedsbeitrag; }
        public static void setMitgliedsbeitrag(double pBeitrag) {
            derMitgliedsbeitrag = pBeitrag;
        }
    }
}
