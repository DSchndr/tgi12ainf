﻿using System;

namespace Übung10
{
    class Program
    {
        static void Main(string[] args) {
            Abteilung a1 = new Abteilung("Lager");
            Abteilung a2 = new Abteilung("Bureau");

            Angestellter m1 = new Angestellter("Hannes Bauer", 100, 10);
            Chef c1 = new Chef("Ivan Ivanovitch Ivanovitchko", 100);

            a1.addMitarbeiter(m1);
            a1.addMitarbeiter(c1);

            a2.addMitarbeiter(c1);

            a1.druckeGehaltsliste();
            a2.druckeGehaltsliste();

            m1.druckeAusweis();
            c1.druckeAusweis();

            c1.setGehalt(200);
            c1.druckeAusweis();
            Console.ReadLine();
        }
    }

    public class Abteilung
    {
        private Mitarbeiter[] dieMitarbeiter = new Mitarbeiter[100];
        private int anzMitarbeiter = 0;

        private string dieBezeichnung;
        public Abteilung(string pBezeichnung) { dieBezeichnung = pBezeichnung; }
        public string getBezeichnung() { return dieBezeichnung; }
        public void addMitarbeiter(Mitarbeiter pMitarbeiter) {
            dieMitarbeiter[anzMitarbeiter++] = pMitarbeiter;
            pMitarbeiter.addAbteilung(this);
        }

        public void druckeGehaltsliste() {
            Console.WriteLine($"Gehaltsliste für die Abteilung {dieBezeichnung}");
            for (int i = 0; i < anzMitarbeiter; i++) {
                Console.WriteLine($"Gehalt für den Mitarbeiter {dieMitarbeiter[i].getName()} ist {dieMitarbeiter[i].getGehalt()}");
            }
            Console.WriteLine("");
        }
    }
    public abstract class Mitarbeiter
    {
        protected string derName;
        protected double dasGehalt;
        private Abteilung[] dieAbteilung = new Abteilung[10];
        private int anzab = 0;

        public Mitarbeiter(string pName, double pGehalt) {
            derName = pName;
            dasGehalt = pGehalt;
        }
        public void addAbteilung(Abteilung pAbteilung) { dieAbteilung[anzab++] = pAbteilung; }
        public string getName() { return derName; }
        public double getGehalt() { return dasGehalt; }
        public abstract int getRaum();
        public void druckeAusweis() {
            Console.WriteLine($"Ausweis für: {derName}\nGehalt {dasGehalt}\nAbteilungen:");
            for (int i = 0; i < anzab; i++) {
                Console.WriteLine($"#{i}: {dieAbteilung[i].getBezeichnung()}");
            }
            Console.WriteLine($"Typ: {this.GetType().Name}");
            if(this.GetType().Name == "Angestellter") Console.WriteLine($"Raum: {this.getRaum()}");
            Console.WriteLine("");
        }
        public virtual void setGehalt(double pGehalt) { dasGehalt = pGehalt; }

    }
    public class Angestellter : Mitarbeiter
    {
        private int derRaum;
        public Angestellter(string pName, double pGehalt, int pRaum) : base(pName, pGehalt) {
            derRaum = pRaum;
        }

        public override int getRaum() { return derRaum; }

    }
    public class Chef : Mitarbeiter
    {
        public Chef(string pName, double pGehalt) : base(pName, pGehalt * 2) { }
        public override int getRaum() { return -1; }
        public override void setGehalt(double pGehalt) { dasGehalt = pGehalt * 2; }
    }
}

